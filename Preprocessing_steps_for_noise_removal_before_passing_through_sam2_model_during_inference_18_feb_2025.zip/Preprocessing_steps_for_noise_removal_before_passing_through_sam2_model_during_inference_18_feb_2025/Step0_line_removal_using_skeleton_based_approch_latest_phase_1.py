from skimage.morphology import skeletonize
import cv2
import numpy as np
import os

mask_dir = "/media/usama/SSD/Data_for_SAM2_model_Finetuning/Data_pipeline_for_sam2_31_oct_2024/Updated_codes_before_sam2_inferencing_14_feb_2025_for_noise_removal/masks/demo122/"
output_dir = "/media/usama/SSD/Data_for_SAM2_model_Finetuning/Data_pipeline_for_sam2_31_oct_2024/Updated_codes_before_sam2_inferencing_14_feb_2025_for_noise_removal/"
mask_dir_out = f"{output_dir}/demo122_18_feb_11"
if not os.path.exists(mixture_dir_out):
    os.makedirs(mixture_dir_out)

mask_images = [f for f in os.listdir(mask_dir)]
for mask_image in mask_images:
    image = cv2.imread(os.path.join(mask_dir, mask_image),cv2.IMREAD_GRAYSCALE)
    # image = cv2.imread(image_path)

    # Binarization
    # _, binary = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY)
    # kernel = np.ones((3, 3), np.uint8) 
    
    blurred = cv2.GaussianBlur(image, (7, 7), 0)


    _, binary = cv2.threshold(blurred,240, 255, cv2.THRESH_BINARY)
    # binary = cv2.morphologyEx(binary,cv2.MORPH_CLOSE,kernel,iterations=8)

    # # Convert to boolean for skimage skeletonize
    binary_bool = binary > 0

    # # Apply skeletonization
    skeleton = skeletonize(binary_bool).astype(np.uint8) * 255
   
    mask = cv2.subtract(binary, skeleton)
   
    
    cv2.imwrite(f"{mask_dir_out}/{mask_image}",mask)
