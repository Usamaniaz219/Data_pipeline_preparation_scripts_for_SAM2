import cv2
import os
import numpy as np

# Set the directory containing images
input_dir = '/media/usama/SSD/Data_for_SAM2_model_Finetuning/Testing_SAM2_on_Meanshift_data/demo161/outputs_after_denoised/demo161/step_6_outputs_11/mask_tiles_/'  
output_dir = '/media/usama/SSD/Data_for_SAM2_model_Finetuning/Testing_SAM2_on_Meanshift_data/demo161/outputs_after_denoised/demo161/step_6_outputs_11/mask_tiles_/'

# Create output directory if it doesn't exist
os.makedirs(output_dir, exist_ok=True)

# Define the kernel for morphological closing
kernel = np.ones((3, 3), np.uint8)  # You can adjust the size based on your requirements

# Iterate through each image in the directory
for filename in os.listdir(input_dir):
    if filename.endswith('.jpg') or filename.endswith('.png') or filename.endswith('.jpeg'):
        # Read the image
        img_path = os.path.join(input_dir, filename)
        img = cv2.imread(img_path)

        if img is None:
            print(f"Failed to read image: {img_path}")
            continue

        # Convert the image to grayscale (optional, based on your use case)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Apply morphological closing
        closing = cv2.morphologyEx(gray, cv2.MORPH_CLOSE, kernel,iterations=5)

        # Save the processed image
        output_path = os.path.join(output_dir, f"{filename}")
        cv2.imwrite(output_path, closing)

        print(f"Processed and saved: {output_path}")

print("All images processed.")
