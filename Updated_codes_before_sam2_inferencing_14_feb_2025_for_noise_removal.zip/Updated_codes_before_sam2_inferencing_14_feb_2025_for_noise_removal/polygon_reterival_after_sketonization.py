

import time
import os
import cv2
import numpy as np
from concurrent.futures import ProcessPoolExecutor
from shapely.geometry import Polygon
from shapely.validation import make_valid

def retrieve_poly(args):
    ori, contours_filled = args
    cnt_ori_2d = np.squeeze(ori)
    if cnt_ori_2d.shape[0] < 4:
        return None

    polygon_ori = Polygon(cnt_ori_2d)
    valid_polygon_ori = make_valid(polygon_ori)
  
    # print("valid polygon original", valid_polygon_ori)

    for cnt_fill in contours_filled:
        
        # print("Contour Filled",cnt_fill)
        cnt_fill_2d = np.squeeze(cnt_fill)
        if cnt_fill_2d.shape[0] <4:
            continue

        polygon_fill = Polygon(cnt_fill_2d)
        polygon_fill = make_valid(polygon_fill)
        # print("walid Polygon fill",polygon_fill)
        if valid_polygon_ori.intersects(polygon_fill):
            return ori
    return None
    

def process_image(image_path,tg_path):
    # image_name = os.path.splitext(os.path.basename(image_path))[0]
    # print(f"Processing image: {image_name}")

    kernel = np.ones((3,3),np.uint8)
    original = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    tg_image = cv2.imread(tg_path,cv2.IMREAD_GRAYSCALE)

    if original is None:
        print(f"Error reading image: {image_path}")
        return None

    # Thresholding to get the original contours
    _, thresh_original = cv2.threshold(original, 20, 255, cv2.THRESH_BINARY)
    # thresh_original = cv2.erode(thresh_original,kernel,iterations=3)
    contours_original, _ = cv2.findContours(thresh_original, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    # Applying median blur and thresholding to get the filled contours
    # median = cv2.medianBlur(original, 3)
    _, thresh_median = cv2.threshold(tg_image, 25, 255, cv2.THRESH_BINARY)
    contours_filled, _ = cv2.findContours(thresh_median, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    # Create a blank mask
    mask = np.zeros(original.shape, dtype=np.uint8)

    # Prepare arguments for parallel processing
    args = []
    for ori in contours_original:
        # area = cv2.contourArea(ori)
        if ori.shape[0] > 3:
            # print("original contours",ori) 
            args.append((ori, contours_filled))
    # args = [(ori, contours_filled) for ori in contours_original if ori.shape[0] > 3]

    # Parallel processing using ProcessPoolExecutor
    with ProcessPoolExecutor(max_workers=os.cpu_count()) as executor:
        results = list(executor.map(retrieve_poly, args))

    # Drawing valid contours on the mask
    for result in results:
        # print("result",result)
        if result is not None:
            cv2.drawContours(mask, [result], -1, 255, cv2.FILLED)
    

    cv2.imwrite("process.jpg", mask)

    # print(f"Image processed: {image_name}")
    return mask
# Load input images
# source_image = "mixture_images_full_7_feb_2025_data_for_testing/ca_lemon_grove_SwinIR_3_mask_ca_lemon_grove_SwinIR_87.jpg"
# target_image = "processed_outputs_7_feb_2025_mixture_11/removed_filled_ca_lemon_grove_SwinIR_3_mask_ca_lemon_grove_SwinIR_87.jpg"

source_images_dir = "/media/usama/SSD/Data_for_SAM2_model_Finetuning/Testing_SAM2_on_Meanshift_data/demo161/outputs/demo161/step_6_outputs/mask_tiles_/"
target_images_dir = "/media/usama/SSD/Data_for_SAM2_model_Finetuning/Testing_SAM2_on_Meanshift_data/demo161/outputs_after_denoised/demo161/step_6_outputs_22/mask_tiles_/"

source_image_files = [f for f in os.listdir(source_images_dir) if f.endswith(".jpg")]
target_images_files = [f for f in os.listdir(target_images_dir) if f.endswith(".jpg")]

# for target_image in target_images_files:
#     source_image_path = os.path.join(source_images_dir,target_image)
#     source_image_path = str(source_image_path)
#     print("source image path",source_image_path)
#     target_image_path = os.path.join(target_images_dir,target_image)
#     source_image = cv2.imread(source_image_path)
#     target_image = cv2.imread(target_image_path)
#     mask = process_image(source_image,target_image)
#     cv2.imwrite("f/{target_images_dir}/{target_image}",mask)

for target_image in target_images_files:
    print("target image",target_image)
    source_image_path = os.path.join(source_images_dir, target_image)
    target_image_path = os.path.join(target_images_dir, target_image)

    mask = process_image(source_image_path, target_image_path)

    output_path = os.path.join(target_images_dir, f"{target_image}")
    cv2.imwrite(output_path, mask)
